<?php

class WPML_Beaver_Builder_Data_Settings_For_Media extends WPML_Beaver_Builder_Data_Settings {

	/**
	 * @return array
	 */
	public function get_fields_to_copy() {
		return [];
	}
}
