<?php

class WPML_Elementor_Media_Node_Slides extends WPML_Elementor_Media_Node_With_Slides {

	protected function get_image_property_name() {
		return 'background_image';
	}
}
