<?php
define('WPML_STICKY_LINKS_FOLDER', basename(WPML_STICKY_LINKS_PATH));

define('WPML_STICKY_LINKS_URL', plugins_url('', dirname(__FILE__)));