<?php

/**
 * Class WPML_TF_AJAX_Exception
 *
 * @author OnTheGoSystems
 */
class WPML_TF_AJAX_Exception extends Exception {

}
